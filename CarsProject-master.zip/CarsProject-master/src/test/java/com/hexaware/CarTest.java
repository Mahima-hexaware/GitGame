package com.hexaware;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.text.ParseException;
//import java.text.SimpleDateFormat;
import java.util.ArrayList;
//import java.util.Date;
import java.util.Date;

import com.hexaware.factory.CarDAO;
import com.hexaware.factory.CarFactory;
import com.hexaware.model.Car;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import mockit.Expectations;
import mockit.Mock;
import mockit.MockUp;
import mockit.Mocked;
import mockit.integration.junit4.JMockit;

@RunWith(JMockit.class)
public class CarTest {

  Car maruthi;
  String pDate;
  //private SimpleDateFormat sdf;

  // setup for testing
  @Before
  public void initInput() throws ParseException
  {
    maruthi = new Car();
    //String date1 = "12/02/2020 10:09:32";
    //sdf = new SimpleDateFormat("dd/MM/YYYY hh:mm:ss");
    //sdf.setLenient(false);
   // pDate = sdf.format(date1);

  }


  @Test
  public void testCardefaultConstructor() {
    Car newCar = new Car();
    assertEquals(newCar.hashCode(), new Car().hashCode());
    newCar.setid(23);
    assertNotEquals(newCar.getid(), new Car().getid());  }
  @Test
  public void testCarParameterisedConstructor() {
     //Date d = new Date("");
      Car newCar = new Car(12,"i10",450000);
      //testing car variables are intialized through getters which in turn to know where its returning a correct values
      assertEquals(12, newCar.getid());
      assertEquals("i10", newCar.getname());
      assertEquals(450000, newCar.getprice());  }
  @Test
  public void testEmployeeSetName() {
    Car newCar1 = new Car(12,"Qualis",450000);
    //testing setName whether the parameter you pass here is correctly initialized to instance variable name of car class
    newCar1.setname("Mercedes");
    assertEquals("Mercedes", newCar1.getname());
  }

  // Testing hashcode and equals and getter and setter methods of Car Class
  @Test
  public final void testCar() {
    //Cars maruthi = new Cars();
    assertNotNull(maruthi);
    Car toyota = null;
    assertNull(toyota);
    Car C100 = new Car(1,"Audi",52642);
    assertEquals(C100, new Car(1,"Audi",52642));
    C100.setid(10);
    assertEquals(10, C100.getid());
    Car[] carList = CarFactory.showMenu();
    assertNotEquals(0, carList.length);
  }

  //tests that empty Car list is handled correctly or not
  //mocking the dao class

  @Test
  public final void testListAllEmpty(@Mocked final CarDAO dao)
  {
    new Expectations() {
      {
        dao.show();
        result = new ArrayList<Car>();
      }
    };
    new MockUp<CarFactory>()
    {
     
      @Mock
      CarDAO dao()
      {
          return dao;
      }

    };

    Car[] car = CarFactory.showMenu();
    assertEquals(0, car.length);
    assertNotEquals(10, car.length);

  }

//Test whether a list with some cars are handled or not

@Test
public final void testListAllSome(@Mocked final CarDAO dao)
{
    final Car  toyota = new Car(15,"toyota",700000);
    final Car Dzire = new Car(15,"Dzire");
    final ArrayList<Car> carList = new ArrayList<Car>();

    new Expectations()
    {

      {
          carList.add(toyota);
          carList.add(Dzire);
          dao.show();
          result = carList;
       }
    };

    new MockUp<CarFactory>()
    {
     
      @Mock
      CarDAO dao()
      {
          return dao;
      }

    };

    Car[] car = CarFactory.showMenu();
    assertEquals(2, car.length);
    assertNotEquals(toyota,new Car(15,"BMW",5000000));
    assertEquals(new Car(15,"Dzire",700000).getid(), car[0].getid());
}








  @After
  public void removeObj()
  {
    maruthi = null;
  }

}
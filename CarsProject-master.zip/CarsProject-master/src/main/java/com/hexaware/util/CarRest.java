package com.hexaware.util;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.hexaware.factory.CarFactory;
import com.hexaware.model.Car;

@Path("/car")
public class CarRest {
  /**
   * Returns Menu details.
   * @return the menu details
   */
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public final Car[] listMenu() {
    final Car[] cars = CarFactory.showMenu();
    return cars;
  }

  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Path("/addCar")
  public final String addCar(final Car newCar) 
  {
      String comment = "";
      final int carIns = CarFactory.insertCar(newCar);
      if(carIns > 0)
      {
        comment = "{\" value \" : \" Car added successfully \"}";
      }
      else{
        comment = "{\" value \" : \" Car not added  \"}";
      }

      return comment;

  }

  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Path("/updateCar")
  public final String updateCar(final Car newCar) 
  {
      String comment = "";
      //final int carIns = CarFactory.insertCar(newCar);
      final int carUpdate = CarFactory.updateCarPrice(newCar);
      if(carUpdate > 0)
      {
        comment = "{\" value \" : \" Car updated successfully \"}";
      }
      else{
        comment = "{\" value \" : \" Car not updated  \"}";
      }

      return comment;

  }


  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @Path("/showCar/{id}")
  public final Car showCar(@PathParam("id") final int carId) {
    final Car car = CarFactory.showCar(carId);
    return car;
  }


}
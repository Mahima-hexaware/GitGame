package com.hexaware.factory;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.hexaware.model.Car;

public class CarFactory {

  protected CarFactory() {

  }

  private static CarDAO dao() {
    DbConnection db = new DbConnection();
    return db.getConnect().onDemand(CarDAO.class);
  }

  public static Car[] showMenu() {
    List<Car> car = dao().show();
    return car.toArray(new Car[car.size()]);
  }

/*   public static int insertCar(int id, String name, int price, String date) throws ParseException {

    final DateFormat carPDateFormatter = new SimpleDateFormat("yyyy-MM-dd");
    final java.util.Date cpdate = carPDateFormatter.parse(date);
    final java.sql.Date scpdate = new java.sql.Date(cpdate.getTime());
    int i = dao().insertCar(id,name,price,scpdate);
    return i;
  } */

  public static int updateCar(Date date,int id) throws ParseException {
    final java.sql.Date scpdate = new java.sql.Date(date.getTime()); 
    int i = dao().updateCar(scpdate,id);
    return i;
  }

public static int insertCar(Car newCar) {
 final int insertResult = dao().insertCar(newCar.getid(),newCar.getname(),newCar.getprice());
 return insertResult;
}


public static int updateCarPrice(Car newCar) {
  //final java.sql.Date scpdate = new java.sql.Date(date.getTime()); 
  int i = dao().updateCarPrice(newCar.getprice(),newCar.getid());
  return i;
}

public static Car showCar(final int carId) {
  CarDAO cDao = dao();
  Car car = cDao.showCar(carId);
  return car;
}
}

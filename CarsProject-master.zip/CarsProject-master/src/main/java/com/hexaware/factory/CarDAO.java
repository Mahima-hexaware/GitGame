package com.hexaware.factory;

import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.SqlUpdate;
import org.skife.jdbi.v2.sqlobject.customizers.Mapper;

import java.sql.Date;
import java.util.List;
import com.hexaware.model.Car;
import com.hexaware.persistance.CarMapper;

public interface CarDAO {

  @SqlQuery("Select * from Cars")
    @Mapper(CarMapper.class)
    List<Car> show();

  @SqlUpdate("Insert into Cars (id,name,price) values (:cid,:cname,:cprice)")
  int insertCar(@Bind("cid") int id,@Bind("cname") String name,@Bind("cprice") int price);

  @SqlUpdate("Update cars SET car_sdate = :s_date where car_id = :cId")
  int updateCar(@Bind("s_date") Date csdate,@Bind("cId") int id);

  @SqlUpdate("Update cars SET price = :pPrice where id = :cId")
  int updateCarPrice(@Bind("pPrice") int pPrice,@Bind("cId") int id);

  @SqlQuery("Select * from Cars where id = :cId")
    @Mapper(CarMapper.class)
  Car showCar(@Bind("cId") int id);
}
